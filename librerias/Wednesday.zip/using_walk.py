import os
acc = 0
for t in os.walk("."):
    dirpath, _, files = t
    for filename in files:
        full_path = os.path.join(dirpath, filename)
        size = os.path.getsize(full_path)
        print(full_path, "ocupa", size, "bytes")
        acc = acc + size
print(f"En total, {acc} bytes")